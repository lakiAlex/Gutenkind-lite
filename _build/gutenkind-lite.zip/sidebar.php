<?php if (!is_active_sidebar('sidebar')) return; ?>

<aside class="widgets">
	<div class="widgets__sidebar">
		<?php dynamic_sidebar('sidebar'); ?>
	</div>
</aside>
