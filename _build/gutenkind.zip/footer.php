<?php get_template_part('parts/footer/footer'); ?>

</div>

<?php wp_footer(); ?>

</body>
</html>
